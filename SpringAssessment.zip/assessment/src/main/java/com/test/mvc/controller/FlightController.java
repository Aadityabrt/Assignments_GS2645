package com.test.mvc.controller;

import java.sql.Date;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.test.mvc.entity.Flight;
import com.test.mvc.entity.Passenger;
import com.test.mvc.dao.FlightDao;

@Controller
public class FlightController {
	@Autowired
	FlightDao fdao;
	
	@GetMapping("/getFlights")
	public String getFlights(@RequestParam String source, @RequestParam String destination, Model model) {
		ArrayList<Flight> flights = fdao.getFlightBySourceAndDestination(source,destination);
		System.out.print(flights.get(0).getFlightId());

		model.addAttribute("flights",flights);
		return "FlightsBooking";
	}
	
	@PostMapping("/addPassengerDetails")
	public String book(@RequestParam("flightId")String flightId, @RequestParam("passengerId") String passengerId, @RequestParam("firstname") String firstName, @RequestParam("lastname") String lastName, @RequestParam("mobile") long mobile, @RequestParam("email") String email, @RequestParam("traveldate") String
			
		travelDate, Model model) {
	    Passenger p = new Passenger(passengerId, firstName, lastName, mobile, email);

	    if(fdao.bookFlight(flightId,p,travelDate))
	    {
	        Flight f = fdao.getFlightById(flightId);
	        model.addAttribute("FlightTemp",f);
	        model.addAttribute("Passenger",p);
	        model.addAttribute("message","Successful;");
	        return "TheEnd";
	    }
	    model.addAttribute("message","Not Succesful");
	    return "TheEnd";

	}
}
