package com.test.mvc.controller;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.test.mvc.entity.User;
import com.test.mvc.dao.FlightDao;
import com.test.mvc.dao.UserDao;

@Controller
public class LoginController 
{
	@Autowired
	UserDao udao;
	
	
	@GetMapping("/loginPage")
	public String getLoginPage()
	{
		return "LoginPage";
	}
	
	@PostMapping("/validateUser")
	public String authenticateUser(@RequestParam("uname") String username, 
			@RequestParam("pword")String password, Model model,HttpServletResponse response) {
		String message = "Invalid username/Password .. TryAgain !";
		User user = new User(username, password);
		if(udao.validateUser(user)) {
			Cookie c = new Cookie("username", username);
			response.addCookie(c);
			return "searchFlights";
		}
			
		model.addAttribute("message", message);
		return "Display";	
	}

	
}