package com.test.mvc.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import com.test.mvc.entity.Flight;
import com.test.mvc.entity.Passenger;
import com.test.mvc.entity.User;

@Repository
public class FlightDao {
	int index = 12;
	private static String url = "jdbc:mysql://localhost:3306/Gainsight";
	public ArrayList<Flight> getFlightBySourceAndDestination(String Source, String Destination) {
		int count = 0;
		ArrayList<Flight> flights = new ArrayList<>();
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(url,"root","Mysql@98366");
			ps = con.prepareStatement("select * from Flights where source = ? and destination = ?");
			ps.setString(1, Source);
			ps.setString(2, Destination);
			rs = ps.executeQuery();
			while(rs.next()) {
				//System.out.print(rs.getString(3));
				Flight temp = new Flight(rs.getString(1), rs.getString(2), rs.getString(3),rs.getDouble(4),rs.getInt(5));
				flights.add(temp);
			}
		    
				
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		finally {
			try {
				if(rs!=null) rs.close();
				if(ps != null) ps.close();
				if(rs!=null) rs.close();
			}
			catch(Exception ex) {
				ex.printStackTrace();
			}
		}
		return flights;
	}
	
	public Flight getFlightById(String flightId) {
	    Flight f = null;
	    Connection conn = null;
	    PreparedStatement pst = null;
	    ResultSet rs=null;
	    try{
	       Class.forName("com.mysql.jdbc.Driver");
	       conn = DriverManager.getConnection(url,"root","Mysql@98366");
	       pst = conn.prepareStatement("select * from Flight where flight_id = ?");
	       pst.setString(1, flightId);
	       
	       
	       rs = pst.executeQuery();
	       if(rs.next())
	          f = new Flight(rs.getString(1),rs.getString(2),rs.getString(3),rs.getDouble(4),rs.getInt(5));
	    }
	    catch(Exception e) {
	       e.printStackTrace();
	    }
	    finally
	    {
	       try
	       {
	          if(rs!=null) rs.close();
	          if(pst!=null) pst.close();
	          if(conn!=null) conn.close();
	       }
	       catch(Exception e)
	       {
	          e.printStackTrace();
	       }
	    }
	       
	    return f;
	}

	public boolean bookFlight(String flightId, Passenger passenger, String travelDate) {
	    
	    Connection conn = null;
	    Connection conn2 = null;
	    PreparedStatement pst = null;
	    PreparedStatement pst2 = null;
	    int count=0, count1 = 0;
	    String bookingId = "BookId" + index;
	    index = index + 1;
	    try{
	       Class.forName("com.mysql.jdbc.Driver");
	       conn = DriverManager.getConnection(url,"root","Mysql@98366");
	       pst = conn.prepareStatement("insert into passenger values(?,?,?,?,?)");
	       pst.setString(1, passenger.getPassengerId());
	       pst.setString(2, passenger.getFirstName());
	       pst.setString(3, passenger.getLastName());
	       pst.setLong(4, passenger.getMobile());
	       pst.setString(5, passenger.getEmail());
	       
	       count = pst.executeUpdate();
	       
	       Class.forName("com.mysql.jdbc.Driver");
	       conn2 = DriverManager.getConnection(url,"root","Mysql@98366");
	       pst2 = conn2.prepareStatement("insert into bookings values(?,?,?,?)");
	       pst2.setString(1, bookingId);
	       pst2.setString(2, flightId);
	       pst2.setString(3, passenger.getPassengerId());
	       pst2.setString(4, travelDate);
	       count1 = pst2.executeUpdate();
	       
	    }
	    catch(Exception e) {
	       e.printStackTrace();
	    }
	    finally
	    {
	       try
	       {
	          if(pst!=null) pst.close();
	          if(pst2!=null) pst2.close();
	          if(conn!=null) conn.close();
	          if(conn2!=null) conn2.close();
	       }
	       catch(Exception e)
	       {
	          e.printStackTrace();
	       }
	    }
	    return count==1 && count1==1;
	}
}
