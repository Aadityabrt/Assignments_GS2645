package com.test.mvc.entity;

public class Passenger {
//1.passenger_id text, 2.first_name text, 3.last_name text, 4.mobile bigint, 5.email text
	private String passengerId;
	private String firstName;
	private String lastName;
	private long mobile;
	private String email;
	public Passenger() {
		
	}
	public Passenger(String passengerId, String firstName, String lastName, long mobile, String email) {
	
		this.passengerId = passengerId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobile = mobile;
		this.email = email;
	}
	public String getPassengerId() {
		return passengerId;
	}
	public void setPassengerId(String passengerId) {
		this.passengerId = passengerId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public long getMobile() {
		return mobile;
	}
	public void setMobile(long mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	
}
